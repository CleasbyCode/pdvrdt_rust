#include "pdvzip.h"

namespace {

std::string readArgsFile(const fs::path& filepath) {
	if (!fs::exists(filepath)) {
		return {};
	}

	const auto file_size = fs::file_size(filepath);
	if (file_size == 0) {
		return {};
	}

	constexpr std::size_t MAX_ARG_LENGTH = 1024;
	if (file_size > MAX_ARG_LENGTH) {
		throw std::runtime_error(std::format(
			"Input Error: Arguments file \"{}\" exceeds maximum length.", filepath.string()));
	}

	std::ifstream ifs(filepath, std::ios::binary);
	if (!ifs) {
		return {};
	}

	std::string data(static_cast<std::size_t>(file_size), '\0');
	ifs.read(data.data(), static_cast<std::streamsize>(file_size));

	// Strip trailing newlines/carriage returns from the args text.
	while (!data.empty() && (data.back() == '\n' || data.back() == '\r')) {
		data.pop_back();
	}

	return data;
}

} // anonymous namespace

UserArguments loadArguments(FileType file_type, const fs::path& linux_args_file,
                            const fs::path& windows_args_file) {
	UserArguments args;

	const bool needs_args =
		(file_type > FileType::PDF && file_type < FileType::UNKNOWN_FILE_TYPE)
		|| file_type == FileType::LINUX_EXECUTABLE
		|| file_type == FileType::JAR;

	if (!needs_args) {
		return args;
	}

	if (file_type != FileType::WINDOWS_EXECUTABLE) {
		args.linux_args = readArgsFile(linux_args_file);
	}

	if (file_type != FileType::LINUX_EXECUTABLE) {
		args.windows_args = readArgsFile(windows_args_file);
	}

	return args;
}
